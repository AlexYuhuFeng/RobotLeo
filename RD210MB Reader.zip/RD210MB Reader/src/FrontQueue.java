
public class FrontQueue {

}
